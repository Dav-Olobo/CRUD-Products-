       
    <!-- Main Content -->
    <main class="py-4 container">
    
 

            <?php $__env->startSection('title', 'Welcome'); ?>

            <?php $__env->startSection('content'); ?>
            <div class="text-center mt-5">
                <p class="fs-4">
                    Hi, <a href="<?php echo e(route('login')); ?>">Login</a> or 
                    <a href="<?php echo e(route('register')); ?>">Register</a> to create a product list.
                </p>
            </div>
            <?php $__env->stopSection(); ?>
    </main>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard\product-crud\resources\views/welcome.blade.php ENDPATH**/ ?>