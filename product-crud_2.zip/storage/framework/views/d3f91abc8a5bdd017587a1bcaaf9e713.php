

<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h1 class="mb-4"><?php echo e($product->name); ?></h1>

    <div class="row">
        <?php if($product->image): ?>
        <div class="col-md-4">
        <img src="<?php echo e(asset($product->image)); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">      
        </div>
        <?php endif; ?>

        <div class="col-md-8">
            <h3>Price: $<?php echo e(number_format($product->price, 2)); ?></h3>
            <p><?php echo e($product->description); ?></p>
            <p><strong>Added by:</strong> <?php echo e($product->user->name ?? 'N/A'); ?></p>
            <?php if(auth()->guard()->check()): ?>

            <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-primary btn-sm">Edit</a>

            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete?')">Delete</button>
            </form>
            <?php endif; ?>

            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary btn-sm">Back to List</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard\product-crud\resources\views/products/view-products.blade.php ENDPATH**/ ?>